from flask import Flask, render_template, request
#from flask_sqlalchemy import SQLAlchemy
import pusher

app = Flask(__name__)
#app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///tasks.db'
#db = SQLAlchemy(app)

## CONFIGURAR O PUSHER!!!!

#channels_client = pusher.Pusher(
#  app_id='851310',
#  key='f33ad87308f0a2730615',
#  secret='3d4288eedec7364e92ad',
#  cluster='us2',
#  ssl=True
#)

#class Tasks(db.Model):
#	id = db.Column(db.Integer, primary_key=True)
#	title = db.Column(db.String(20))
#	date = db.Column(db.String(10)) 
#	priority = db.Column(db.String(5))

@app.route('/')
@app.route('/index')
def index():
#	tasks = Tasks.query.all()
	return render_template('home.html') #, tasks=tasks

#@app.route('/task', methods=['POST'])
#def task():
#	try:
#		title = request.form.get('title')
#		date = request.form.get('date')
#		priority = request.form.get('priority')
#
#		new_task = Message(title=title, date=date, priority=priority)
#		db.session.add(new_task)
#		db.session.commit()
#
#		channels_client.trigger('my-channel', 'my-event', {'message': 'hello world'})
#
#		return jsonify({'result': 'success'})
#
#	except:
#		return jsonify({'result': 'failure'})

if __name__ == '__main__':
	app.run(debug=True)